/**
 * Hello, u're looking to steal my code, good luck!
 * If I were you I would at least ask permission before that,
 * I would be happy instead of you stealing my code and having to take drastic measures.
 * Well, thank you, Gabriel Aplok.
 *
 * It took me about 4-6 months to design all of this systems. ❤️
*/

import "bullet.js";
import "command.js";