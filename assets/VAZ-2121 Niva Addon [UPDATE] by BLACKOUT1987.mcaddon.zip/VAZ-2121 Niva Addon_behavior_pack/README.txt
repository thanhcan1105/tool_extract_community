ENG:

This addon was created and owned by Blackout1987. Reposting or editiong the files of this addon without the permission of the creator may have legal consequences, as well as subsequent copyright strikes. 

РУС:

Данный аддон был создан и принадлежит Blackout1987. Репост либо изменение файлов этого аддона без разрешения автора могут иметь правовые последствия, а также последующие страйки по авторским правам.

ESP:

Este addon fue creado y es propiedad de Blackout1987. El reposteo o la addon de los archivos de este complemento sin el permiso del creador pueden tener consecuencias legales, incluyendo acciones por derechos de creador y posibles sanciones.